const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express(); // Initialize the express app
const PORT = 5000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// MySQL Connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Replace with your MySQL username
  password: '*#@MySQL11.Acc', // Replace with your MySQL password
  database: 'textilesync'
});

db.connect(err => {
  if (err) throw err;
  console.log('MySQL Connected...');
});

// API Endpoint - Test Connection
app.get('/', (req, res) => {
  res.send('TextileSync API Running...');
});

// Example API - Fetch Stock
app.get('/api/stock', (req, res) => {
  const query = 'SELECT * FROM stock';
  db.query(query, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// API Endpoint - Register User
app.post('/api/register', (req, res) => {
  const { username, email, password } = req.body;
  const query = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
  db.query(query, [username, email, password], (err, results) => {
    if (err) {
      console.error('Error while inserting user:', err);
      return res.status(500).json({ message: 'Registration failed. Please try again.' });
    }
    res.status(201).json({ message: 'User registered successfully!' });
  });
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

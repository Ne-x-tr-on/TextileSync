const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 5000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// MySQL Connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Replace with your MySQL username
  password: '*#@MySQL11.Acc', // Replace with your MySQL password
  database: 'textilesync'
});

db.connect(err => {
  if (err) throw err;
  console.log('MySQL Connected...');
});

// API Endpoint - Test Connection
app.get('/', (req, res) => {
  res.send('TextileSync API Running...');
});

// Example API - Fetch Stock
app.get('/api/stock', (req, res) => {
  const query = 'SELECT * FROM stock';
  db.query(query, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
